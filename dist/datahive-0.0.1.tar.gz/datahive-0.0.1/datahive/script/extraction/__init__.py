# -*- coding: utf-8 -*-
"""
@Description: 
@Date       : 2025/3/2 1:25
@Author     : lkkings
@FileName:  : __init__.py
@Github     : https://github.com/lkkings
@Mail       : lkkings888@gmail.com
-------------------------------------------------
Change Log  :

"""
from datahive.script.extraction._factory import factory