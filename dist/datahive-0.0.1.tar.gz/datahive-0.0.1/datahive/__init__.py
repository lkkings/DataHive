# -*- coding: utf-8 -*-
"""
@Description: 
@Date       : 2025/3/1 20:40
@Author     : lkkings
@FileName:  : __init__.py
@Github     : https://github.com/lkkings
@Mail       : lkkings888@gmail.com
-------------------------------------------------
Change Log  :

"""
__author__ = "lkkings"
__version__ = "0.0.1"
__description_cn__ = "[red]数据处理[/red] [green]工具[/green]"
__description_en__ = "[red] Data Processor[/red] [green]Tools[/green]"
__reponame__ = "DataHive"
__repourl__ = "https://github.com/lkkings/DataHive.git"
