# -*- coding: utf-8 -*-
"""
@Description: 
@Date       : 2025/3/1 20:43
@Author     : lkkings
@FileName:  : __main__.py
@Github     : https://github.com/lkkings
@Mail       : lkkings888@gmail.com
-------------------------------------------------
Change Log  :

"""
from datahive.cli.cli_commands import main

main()
